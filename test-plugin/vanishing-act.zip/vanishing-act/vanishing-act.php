<?php
/**
 * Plugin Name:       Vanishing Act (Test Plugin)
 * Description:       A harmless test plugin. Once switched on, your home page does a disappearing trick and shows "Page not found". Everything else, including the dashboard, keeps working. Built for testing The Hack Repair Guy's Plugin Detective. Not for real sites.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Jim Walker, The Hack Repair Guy
 * Author URI:        https://hackrepair.com/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       vanishing-act
 *
 * @package Vanishing_Act
 */

defined( 'ABSPATH' ) || exit;

/**
 * Turn the home page into a 404. Only the public front page is affected, never
 * the dashboard, login, REST API or any other page.
 */
function vanishing_act_hide_home(): void {
	if ( is_admin() || ! ( is_front_page() || is_home() ) ) {
		return;
	}

	global $wp_query;
	$wp_query->set_404();
	status_header( 404 );
	nocache_headers();

	$template = get_404_template();
	if ( $template ) {
		include $template;
		exit;
	}

	wp_die( esc_html__( 'Page not found.', 'vanishing-act' ), esc_html__( 'Page not found', 'vanishing-act' ), array( 'response' => 404 ) );
}
add_action( 'template_redirect', 'vanishing_act_hide_home', 1 );
