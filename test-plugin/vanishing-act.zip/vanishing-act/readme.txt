=== Vanishing Act (Test Plugin) ===
Contributors: hackrepair
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

A harmless plugin that makes your home page show "Page not found", for testing The Hack Repair Guy's Plugin Detective.

== Description ==

Install it, switch it on, and the home page shows a 404. Switch it off and the home page comes back. The dashboard and every other page keep working.

Built only to give Plugin Detective something to find. Don't use it on a live site.

== Changelog ==

= 1.0.0 =
* First release.
